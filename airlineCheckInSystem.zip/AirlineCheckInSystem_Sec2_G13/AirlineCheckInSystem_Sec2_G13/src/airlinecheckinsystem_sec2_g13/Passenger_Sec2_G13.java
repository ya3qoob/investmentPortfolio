/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlinecheckinsystem_sec2_g13;

import java.util.ArrayList;

/**
 *
 * Assignment 2 - Group 13 - Mahmoud Soliman 1080291 - Yaqoob Arshad 1085654 -
 * Imtiyaz Ali 1085124 
 */
public class Passenger_Sec2_G13 {

    // Attributes of passenger
    private String id;
    private String name;
    private String ticketClass;
    private int luggageCount;
    private static int numOfPassengers = 0;
    private ArrayList<String> tags;
    private int priorityScore;

    // Constructor
    public Passenger_Sec2_G13(String name, String ticketClass, int priorityScore, ArrayList<String> tags) {
        this.id = String.valueOf(++numOfPassengers);
        this.name = name;
        this.ticketClass = ticketClass;
        this.priorityScore = priorityScore;
        this.tags = tags;
    }

    public int getPriorityScore() {
        return priorityScore;
    }

    public void setPriorityScore(int priorityScore) {
        this.priorityScore = priorityScore;
    }

    public void addTag(String tag) {
        tags.add(tag);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTicketClass() {
        return ticketClass;
    }

    public void setTicketClass(String ticketClass) {
        this.ticketClass = ticketClass;
    }

    public int getLuggageCount() {
        return luggageCount;
    }

    public void addLuggage() {
        luggageCount++;
    }

    public void removeLuggage() {
        luggageCount--;
    }

    public void setLuggageCount(int luggageCount) {
        this.luggageCount = luggageCount;
    }

    // Returns information of Passenger
    @Override
    public String toString() {
        return "ID: "+id+", Name: "+name+", Ticket Class: "+ticketClass+
                " Luggage count: "+luggageCount+" tags: "+tags+", Priority Score: "+priorityScore;
    }
}
