/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package airlinecheckinsystem_sec2_g13;

import java.util.*;

/**
 *
 * Assignment 2 - Group 13 - Mahmoud Soliman 1080291 - Yaqoob Arshad 1085654 -
 * Imtiyaz Ali 1085124 This is the main class for the AirlineCheckInSystem, it
 * has several types of data structures, including Queue, Stack, PriorityQueue,
 * and ArrayList. This class allows the user to navigate through a user
 * interface and select one of the available functionalities such as, Queue
 * Passenger, Dequeue Passenger Pop luggage, View Next Passenger, View Top
 * Luggage.
 */
public class AirlineCheckInSystem_Sec2_G13 {

    /**
     * @param args the command line arguments
     */
    // Data Structures for passengers and luggage
    private Queue<Passenger_Sec2_G13> passengersQueue;
    private Stack<Luggage_Sec2_G13> luggageStack;
    private PriorityQueue<Passenger_Sec2_G13> priorityServicesQueue;
    private ArrayList<Passenger_Sec2_G13> passengerList;

    // Constructor
    public AirlineCheckInSystem_Sec2_G13() {
        this.passengersQueue = new LinkedList<>();
        this.luggageStack = new Stack<>();
        this.priorityServicesQueue = new PriorityQueue<>(new PriorityServices_Sec2_G13());
        this.passengerList = new ArrayList<>();
    }

    // Queues the passenger in the normal queue
    public void enqueuePassenger(Passenger_Sec2_G13 passenger) {
        passengersQueue.offer(passenger);
        System.out.println("Boarded: " + passenger);
        // Logic to add passenger to the passengers queue
    }

    // Queues the passenger in the priority queue
    public void enqueuePriorityPassenger(Passenger_Sec2_G13 passenger) {
        // Logic to add passenger to the priority services queue
        priorityServicesQueue.offer(passenger);
        System.out.println("Priority Boarded: " + passenger);
    }

    // Adds the luggage on top of the stack
    public void pushLuggage(Luggage_Sec2_G13 luggage) {
        // Logic to push luggage to the luggage stack
        luggageStack.push(luggage);
    }

    // Dequeues passengers based on priority first.
    public Passenger_Sec2_G13 dequeuePassenger() {
        // if the priority queue has a passenger, they are dequeud first
        if (!priorityServicesQueue.isEmpty()) {
            return priorityServicesQueue.poll();
        } else if (!passengersQueue.isEmpty()) {
            return passengersQueue.poll();
        }
        return null;  // Placeholder
    }

    public Luggage_Sec2_G13 popLuggage() {
        if (!luggageStack.isEmpty()) {
            return luggageStack.pop();
        }
        return null;//Placeholder
    }

    // Returns the passenger based on priority
    public Passenger_Sec2_G13 getNextPassenger() {
        // if the priority queue has a passenger, they are returned first before normal passengers
        if (!priorityServicesQueue.isEmpty()) {
            return priorityServicesQueue.peek();
        } else if (!passengersQueue.isEmpty()) {
            return passengersQueue.peek();
        } else {
            return null;//Placeholder
        }
    }

    // returns the top luggage from the stack
    public Luggage_Sec2_G13 getTopLuggage() {
        if (!luggageStack.isEmpty()) {
            return luggageStack.peek();  // Placeholder
        } else {
            return null;
        }
    }

    // adds passenger to passengerList
    public void registerPassenger(Passenger_Sec2_G13 passenger) {
        passengerList.add(passenger);
    }

    // THE MAIN METHOD
    public static void main(String[] args) {
        AirlineCheckInSystem_Sec2_G13 checkInSystem = new AirlineCheckInSystem_Sec2_G13(); // Initialize checkInSystem
        Scanner scanner = new Scanner(System.in); // Initialize scanner
        Passenger_Sec2_G13 tempPassenger; // Declaration of temp passenger
        Luggage_Sec2_G13 tempLuggage; // Declaration of temp luggage
        // Loop to keep the interface running until the user exits.
        while (true) {
            try {
                // Interface
                System.out.println("------------------------------------------");
                System.out.println("Airline Check-In System Menu:");
                System.out.println("1. Queue Passenger");
                System.out.println("2. Dequeue Passenger");
                System.out.println("3. Pop Luggage");
                System.out.println("4. View Next Passenger");
                System.out.println("5. View Top Luggage");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                System.out.println("------------------------------------------");
                scanner.nextLine();  // Consume newline left-over
                // Switch that runs  the chosen function
                switch (choice) {
                    case 1:
                        // User inputs passenger name
                        System.out.print("Enter Passenger Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Ticket Class\n0: Exit\n1: Economy\n2: Business\n3: First-Class ");
                        String ticketClass = null;
                        // User inputs ticket type, loops if input is invalid
                        do {
                            choice = scanner.nextInt();
                            ticketClass = (choice == 1) ? "Economy" : (choice == 2) ? "Business" : (choice == 3) ? "First-Class" : null;
                        } while (choice < 0 || choice > 3);
                        // if user chooses to exit, breaks out of switch
                        if (ticketClass == null) {
                            System.out.println("Exiting Registering. . . ");
                            break;
                        }

                        // ticket class adds 25 points if business, 50 if first-class, 0 if economy
                        int PP = (ticketClass.equals("Business") ? 25 : (ticketClass.equals("First-Class") ? 50 : 0)); // priority-points
                        String tempTag;
                        ArrayList<String> tempTags = new ArrayList<>();
                        // Start of Do-While loop that loops to allow assigning multiple health problems
                        do {
                            // interface for health problems
                            System.out.println("Choose one of the available health problems\n0: None\n1: Elder"
                                    + "\n2: Wheelchair\n3: Amputee\n4: Human Submarine\n5: Mental Illness\n6: Blind");
                            choice = scanner.nextInt();
                            // Assign tempTag based on choice
                            tempTag = (choice == 1) ? "Elder" : (choice == 2) ? "Wheelchair" : (choice == 3) ? "Amputee"
                                    : (choice == 4) ? "Human Submarine" : (choice == 5) ? "Mental Illness" : (choice == 6) ? "Blind" : "";
                            // checks if tag already has been added to passenger, if yes skip to end of the loop.
                            if (tempTags.contains(tempTag)) {
                                System.out.println(tempTag + " is already assigned.");
                                continue;
                            }
                            // Adds points based on choice
                            switch (choice) {
                                case 0:
                                    break;
                                case 1:
                                    PP += 75;
                                    break;
                                case 2:
                                    PP += 75;
                                    break;
                                case 3:
                                    PP += 75;
                                    break;
                                case 4:
                                    PP += 60;
                                    break;
                                case 5:
                                    PP += 55;
                                    break;
                                case 6:
                                    PP += 80;
                                    break;
                                default:
                            }
                            System.out.println("Assigned: " + tempTag);
                            tempTags.add(tempTag);
                        } while (choice != 0);
                        // End of Do-While Loop

                        tempPassenger = new Passenger_Sec2_G13(name, ticketClass, PP, tempTags); // temp Passenger to be Added

                        if (PP == 0) {
                            checkInSystem.registerPassenger(tempPassenger);
                            checkInSystem.enqueuePassenger(tempPassenger);
                        } else {
                            checkInSystem.registerPassenger(tempPassenger);
                            checkInSystem.enqueuePriorityPassenger(tempPassenger);
                        }

                        // start of do-while, loops the luggage adding process while luggage count is less than 4 or user has no luggage
                        do {
                            try {
                                System.out.println("Do you want to add luggage?\n1: Yes\n2: No ");
                                choice = scanner.nextInt();
                                // Skip to end of do-while loop
                                if (choice == 2) {
                                    continue;
                                }

                                double weight, height, width, length;
                                String dimensions = "";
                                // Start of do-while, loops if input is invalid
                                do {
                                    System.out.println("Enter Luggage Weight in KG (Max 50)");
                                    weight = scanner.nextDouble();
                                    scanner.nextLine();
                                    System.out.println("Enter Length (Max 90 cm)");
                                    length = scanner.nextDouble();
                                    System.out.println("Enter Width (Max 60 cm)");
                                    width = scanner.nextDouble();
                                    System.out.println("Enter Height (Max 40 cm)");
                                    height = scanner.nextDouble();
                                    dimensions = length + "x" + width + "x" + height;
                                } while ((weight <= 0 || weight > 50 || length <= 0 || length > 90
                                        || width <= 0 || width > 60 || height <= 0 || height > 40));
                                // end of do-while loop

                                tempLuggage = new Luggage_Sec2_G13(tempPassenger.getId(), weight, dimensions); // temp luggage
                                checkInSystem.pushLuggage(tempLuggage); // luggage is pushed
                                tempPassenger.addLuggage(); // luggage count is incremented
                                System.out.println("Added luggage: " + tempLuggage);
                            } catch (InputMismatchException ex) {
                                System.out.println("Error. . . Restarting Luggage adding Process.");
                                scanner.nextLine();
                            }
                        } while (choice != 2 && tempPassenger.getLuggageCount() != 3);
                        // end of do-while
                        break;
                    case 2:
                        // Calls dequeue method, if no passengers are in any of the queues, print a notice, else print passenger info.
                        tempPassenger = checkInSystem.dequeuePassenger();
                        if (tempPassenger == null) {
                            System.out.println("No passengers to dequeue.");
                        } else {
                            System.out.println("Passenger: " + tempPassenger.getName() + " is off the plane.");
                        }
                        break;
                    case 3:
                        // Calls pop luggage method, if no luggages exist, print a notice, else print luggage info.
                        tempLuggage = checkInSystem.popLuggage();
                        if (tempLuggage == null) {
                            System.out.println("No luggages.");
                        } else {
                            System.out.println("Popped: " + tempLuggage);
                        }
                        break;
                    case 4:
                        // Calls getNextPassener method, if no passengers are in any of the queues, print a notice, else print passenger info.
                        tempPassenger = checkInSystem.getNextPassenger();
                        if (tempPassenger == null) {
                            System.out.println("No passengers to view.");
                        } else {
                            System.out.println("Next Passenger: " + tempPassenger.getName());
                        }
                        break;
                    case 5:
                        // Calls getTopLuggage method, if no luggages exist, print a notice, else print luggage info.
                        tempLuggage = checkInSystem.getTopLuggage();
                        if (tempLuggage == null) {
                            System.out.println("No luggages available.");
                        } else {
                            System.out.println("Top Luggage: " + tempLuggage);
                        }
                        break;
                    case 6:
                        // exit system
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } catch (InputMismatchException ex) {
                System.out.println("Error. . . Exiting to Main Menu");
                scanner.nextLine();
            }
        }
    }

}
