/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlinecheckinsystem_sec2_g13;

/**
 *
 * Assignment 2 - Group 13 - Mahmoud Soliman 1080291 - Yaqoob Arshad 1085654 -
 * Imtiyaz Ali 1085124 
 */
public class Luggage_Sec2_G13 {

    //Attributes of luggage
    private String id;
    private String passengerId;
    private double weight;
    private String dimensions;
    private static int numOfLuggages = 0;

    // Constructor
    public Luggage_Sec2_G13(String passengerId, double weight, String dimensions) {
        this.id = String.valueOf(++numOfLuggages);
        this.passengerId = passengerId;
        this.weight = weight;
        this.dimensions = dimensions;
    }
    
    // Returns Luggage information
    public String toString(){
        return "ID: "+id+", Passenger ID: "+passengerId+", Weight: "+weight+
                " KG, Dimensions: "+dimensions+" LxWxH";
    }
}
