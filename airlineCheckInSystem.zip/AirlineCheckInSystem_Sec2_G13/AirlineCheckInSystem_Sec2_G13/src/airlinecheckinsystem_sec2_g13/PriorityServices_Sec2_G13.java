/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlinecheckinsystem_sec2_g13;

import java.util.Comparator;

/**
 *
 * Assignment 2 - Group 13 - Mahmoud Soliman 1080291 - Yaqoob Arshad 1085654 -
 * Imtiyaz Ali 1085124 
 */
public class PriorityServices_Sec2_G13 implements Comparator<Passenger_Sec2_G13> {

    @Override
    // Compares between passengers, higher priority is served first
    public int compare(Passenger_Sec2_G13 o1, Passenger_Sec2_G13 o2) {
        if (o1.getPriorityScore() < o2.getPriorityScore()) {
            return 1;
        } else if (o1.getPriorityScore() > o2.getPriorityScore()) {
            return -1;
        } else {
            return 0;
        }
    }
}
